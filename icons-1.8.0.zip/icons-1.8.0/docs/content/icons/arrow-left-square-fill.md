---
title: Arrow left square fill
layout: icon
categories:
  - Shape Arrows
tags:
  - arrow
  - square
---
