---
title: Caret left square
layout: icon
categories:
  - Carets
tags:
  - caret
  - arrow
  - triangle
---
